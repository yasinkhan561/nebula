

<?php $__env->startSection("content"); ?>

<div class="row">
    <div class="col-md-12" styes="padding:inherit 20px !important">
        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible show" role="alert" >
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?></div>

        <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible show" role="alert" >
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    </div>


    <div class=" col-md-6" >
    <div class="panel" >
        <div class="panel-heading">
            <h1 class="panel-title"><strong>Create Status</strong></h1>
        </div>
        <div class="panel-body">
            <form class="form-horizontal" action="<?php echo e(route('statuses.store')); ?>" method="POST" >
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <input type="text" class="form-control" name="status" placeholder="Status" required>
                </div>
                <div class="form-group">
                    <div class="col-lg-12">
                        <button class="btn btn-primary" type="submit">Save</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    </div>

    <div class="col-md-6">
    <div class="panel">
        <div class="panel-heading bord-btm clearfix pad-all h-100">
            <h1 class="panel-title"><strong>Status  Management</strong></h1>
        </div>
        <div class="panel-body">
            <table class="table table-striped table-vcenter res-table mar-no" cellspacing="0" width="100%">
                <thead>
                    <tr>
                        <th scope="col" class="px-4 py-3">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                        <?php if($status != null): ?>
                            <tr>
                                <td scope="row" class="font-weight-bold text-dark">
                                    <?php echo e($status->status); ?>

                                </td>

                        
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
     </div>
    </div>
</div>
   

<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nebula\resources\views/statuses/index.blade.php ENDPATH**/ ?>