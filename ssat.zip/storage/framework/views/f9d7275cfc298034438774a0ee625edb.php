<?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
  <td><?php echo e($page->website ? $page->website->title : 'N/A'); ?></td>
  <td><?php echo e($page->batch); ?></td>
  <td><a href="<?php echo e($page->url); ?>">View Page</a></td>
  <td><?php echo e($page->nodes); ?></td>
  <td><?php echo e($page->critical); ?></td>
  <td><?php echo e($page->serious); ?></td>
  <td><?php echo e($page->moderate); ?></td>
  <td><?php echo e($page->minor); ?></td>
  <td><?php echo e($page->score); ?></td>
  <td><?php echo e($page->aria); ?></td>
  <td><?php echo e($page->forms); ?></td>
  <td><?php echo e($page->name_role_value); ?></td>
  <td><?php echo e((new DateTime($page->scan_time))->format('m/d/Y')); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\nebula\resources\views/pages/partials/page-rows.blade.php ENDPATH**/ ?>