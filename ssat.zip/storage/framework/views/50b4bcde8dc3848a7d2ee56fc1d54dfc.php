

<?php $__env->startSection("content"); ?>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

    <div class="panel col-md-8 col-md-offset-2 " style="margin-top:50px;padding-top:30px">
        <div class="panel-heading">
            <h1 class="panel-title"><strong>Import <?php echo e($tool->name); ?> Results</strong></h1>
        </div>
        <div class="panel-body">
            <form class="form-horizontal" action="<?php echo e(route('violations.import.process')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                
                <div class="select form-group" >
                            <select class="form-control demo-select2" name="website" id="website"  required>
                                <option value="">Choose website</option>
                                <?php $__currentLoopData = $websites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $website): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($website->id); ?>"><?php echo e($website->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                </div>
        
                <div class="form-group">
                    <input type="file" class="form-control" name="bulk_file" required>
                </div>
                <div class="form-group">
                    <div class="col-lg-12">
                        <button class="btn btn-primary" type="submit">Import</button>
                    </div>
                </div>
            </form>
        </div>
    </div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nebula\resources\views/violations/import.blade.php ENDPATH**/ ?>