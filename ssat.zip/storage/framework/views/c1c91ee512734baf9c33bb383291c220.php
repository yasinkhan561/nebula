

<?php $__env->startSection("content"); ?>

<div class="row">
    <div class="col-md-12" styes="padding:inherit 20px !important">
        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible show" role="alert" >
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?></div>

        <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible show" role="alert" >
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    </div>


    <div class=" col-md-4" >
    <div class="panel" >
        <div class="panel-heading">
            <h1 class="panel-title"><strong>Upload Website Information</strong></h1>
        </div>
        <div class="panel-body">
            <form class="form-horizontal" action="<?php echo e(route('websites.store')); ?>" method="POST" >
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <select class="form-control demo-select2" name="tool_id" required>
                    <option value="">Select Testing Tool</option>
                        <?php $__currentLoopData = $tools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tool->id); ?>"><?php echo e($tool->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="title" placeholder="Title" required>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="url"  placeholder="Website Url">
                </div>
                <div class="form-group">
                    <div class="col-lg-12">
                        <button class="btn btn-primary" type="submit">Save</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    </div>

    <div class="col-md-8">
    <div class="panel">
        <div class="panel-heading bord-btm clearfix pad-all h-100">
            <h1 class="panel-title"><strong>Tested Websites</strong></h1>
        </div>
        <div class="panel-body">
            <table class="table table-striped table-vcenter res-table mar-no sortable " cellspacing="0" width="100%">
                <thead>
                    <tr>
                        <th scope="col" class="px-4 py-3">Testing Tool</th>
                        <th scope="col" class="px-4 py-3">Title</th>
                        <th scope="col" class="px-4 py-3">Url</th>
                        <th width="10%">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $websites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $website): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                        <?php if($website != null): ?>
                            <tr>
                                <td scope="row" class="font-weight-bold text-dark">
                                    <?php echo e($website->tool->name); ?>

                                </td>
                                <td scope="row" class="font-weight-bold text-dark">
                                    <?php echo e($website->title); ?>

                                </td>
                                <td scope="row" class="font-weight-bold text-dark">
                                    <?php echo e($website->url); ?>

                                </td>
                               
                                <td>
                                    <a class="btn btn-primary" onclick="confirm_modal('<?php echo e(route('website.remove', $website->id)); ?>');"><i class="fa fa-trash"></i></a>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
     </div>
    </div>
</div>
   

<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nebula\resources\views/websites/index.blade.php ENDPATH**/ ?>