<?php 
    $firstToolName = App\Models\Tool::find(1)->name; 
    $secondToolName = App\Models\Tool::find(2)->name;
   ?>

<header id="navbar">
    <div id="navbar-container" class="boxed">
        <div class="navbar-content">
            <ul class="nav navbar-top-links navbar-left">                          
                <li >
                    <a  href="<?php echo e(route('websites.index')); ?>">
                       <strong>Tested Websites </strong>
                    </a>
                </li>
                <li >
                    <a  href="<?php echo e(route('pages.index')); ?>">
                    <strong> Pages </strong>
                    </a>
                </li>
             
                <li>
                    <a  href="<?php echo e(route('violations.index')); ?>">
                    <strong><?php echo e($secondToolName); ?></strong>
                    </a>
                </li>
                <li>
                    <a  href="<?php echo e(route('issues.index')); ?>">
                    <strong> <?php echo e($firstToolName); ?></strong>
                    </a>
                </li>
               
                <li>
                    <a  href="<?php echo e(route('statuses.index')); ?>">
                       <strong> Status Management</strong>
                    </a>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><strong> Import</strong> <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li>
                            <a  href="<?php echo e(route('issues.import')); ?>">
                            <strong> <?php echo e($secondToolName); ?> Results </strong>
                            </a>
                        </li>
                        <li>
                            <a  href="<?php echo e(route('violations.import')); ?>">
                            <strong><?php echo e($firstToolName); ?> Results</strong>
                            </a>
                        </li>
                    </ul>
                </li>

            </ul>
    
        </div>
        <!--================================-->
        <!--End Navbar Dropdown-->

    </div>
</header>
<?php /**PATH C:\xampp\htdocs\nebula\resources\views/nav.blade.php ENDPATH**/ ?>