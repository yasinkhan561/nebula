<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link name="favicon" type="image/x-icon" href="<?php echo e(my_asset('favicon.ico')); ?>" rel="shortcut icon" />

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">

    <!--Bootstrap Stylesheet [ REQUIRED ]-->
    <link href="<?php echo e(my_asset('css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!--active-shop Stylesheet [ REQUIRED ]-->
    <link href="<?php echo e(my_asset('css/active-shop.min.css')); ?>" rel="stylesheet">

    <!--active-shop Premium Icon [ DEMONSTRATION ]-->
    <link href="<?php echo e(my_asset('css/demo/active-shop-demo-icons.min.css')); ?>" rel="stylesheet">

    <!--Font Awesome [ OPTIONAL ]-->
    <link href="<?php echo e(my_asset('plugins/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">

    <!--Switchery [ OPTIONAL ]-->
    <link href="<?php echo e(my_asset('plugins/switchery/switchery.min.css')); ?>" rel="stylesheet">

    <!--DataTables [ OPTIONAL ]-->
    <link href="<?php echo e(my_asset('plugins/datatables/media/css/dataTables.bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(my_asset('plugins/datatables/extensions/Responsive/css/responsive.dataTables.min.css')); ?>" rel="stylesheet">

    <!--Select2 [ OPTIONAL ]-->
    <link href="<?php echo e(my_asset('plugins/select2/css/select2.min.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(my_asset('css/bootstrap-select.min.css')); ?>" rel="stylesheet">

    <!--Chosen [ OPTIONAL ]-->
    

    <!--Bootstrap Tags Input [ OPTIONAL ]-->
    <link href="<?php echo e(my_asset('plugins/bootstrap-tagsinput/bootstrap-tagsinput.min.css')); ?>" rel="stylesheet">

    <!--Summernote [ OPTIONAL ]-->
    <link href="<?php echo e(my_asset('css/jodit.min.css')); ?>" rel="stylesheet">

    <!--Theme [ DEMONSTRATION ]-->
    <!-- <link href="<?php echo e(my_asset('css/themes/type-full/theme-dark-full.min.css')); ?>" rel="stylesheet"> -->
    <link href="<?php echo e(my_asset('css/themes/type-c/theme-navy.min.css')); ?>" rel="stylesheet">

    <!--Spectrum Stylesheet [ REQUIRED ]-->
    <link href="<?php echo e(my_asset('css/spectrum.css')); ?>" rel="stylesheet">

    <!--Custom Stylesheet [ REQUIRED ]-->
    <link href="<?php echo e(my_asset('css/custom.css')); ?>" rel="stylesheet">


    <!--JAVASCRIPT-->
    <!--=================================================-->

    <!--jQuery [ REQUIRED ]-->
    <script src=" <?php echo e(my_asset('js/jquery.min.js')); ?>"></script>


    <!--BootstrapJS [ RECOMMENDED ]-->
    <script src="<?php echo e(my_asset('js/bootstrap.min.js')); ?>"></script>


    <!--active-shop [ RECOMMENDED ]-->
    <script src="<?php echo e(my_asset('js/active-shop.min.js')); ?>"></script>

    <!--Alerts [ SAMPLE ]-->
    <script src="<?php echo e(my_asset('js/demo/ui-alerts.js')); ?>"></script>

    <!--Switchery [ OPTIONAL ]-->
    <script src="<?php echo e(my_asset('plugins/switchery/switchery.min.js')); ?>"></script>

    <!--DataTables [ OPTIONAL ]-->
    <script src="<?php echo e(my_asset('plugins/datatables/media/js/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(my_asset('plugins/datatables/media/js/dataTables.bootstrap.js')); ?>"></script>
    <script src="<?php echo e(my_asset('plugins/datatables/extensions/Responsive/js/dataTables.responsive.min.js')); ?>"></script>

    <!--DataTables Sample [ SAMPLE ]-->
    <script src="<?php echo e(my_asset('js/demo/tables-datatables.js')); ?>"></script>

    <!--Select2 [ OPTIONAL ]-->
    <script src="<?php echo e(my_asset('plugins/select2/js/select2.min.js')); ?>"></script>
    <script src="<?php echo e(my_asset('js/bootstrap-select.min.js')); ?>"></script>

    <!--Summernote [ OPTIONAL ]-->
    <script src="<?php echo e(my_asset('js/jodit.min.js')); ?>"></script>

    <!--Bootstrap Tags Input [ OPTIONAL ]-->
    <script src="<?php echo e(my_asset('plugins/bootstrap-tagsinput/bootstrap-tagsinput.min.js')); ?>"></script>

    <!--Bootstrap Validator [ OPTIONAL ]-->
    <script src="<?php echo e(my_asset('plugins/bootstrap-validator/bootstrapValidator.min.js')); ?>"></script>

    <!--Bootstrap Wizard [ OPTIONAL ]-->
    <script src="<?php echo e(my_asset('plugins/bootstrap-wizard/jquery.bootstrap.wizard.min.js')); ?>"></script>

    <!--Bootstrap Datepicker [ OPTIONAL ]-->
    <script src="<?php echo e(my_asset('plugins/bootstrap-datepicker/bootstrap-datepicker.min.js')); ?>"></script>

    <!--Form Component [ SAMPLE ]-->
    <script src="<?php echo e(my_asset('js/demo/form-wizard.js')); ?>"></script>

    <!--Spectrum JavaScript [ REQUIRED ]-->
    <script src="<?php echo e(my_asset('js/spectrum.js')); ?>"></script>

    <!--Spartan Image JavaScript [ REQUIRED ]-->
    <script src="<?php echo e(my_asset('js/spartan-multi-image-picker-min.js')); ?>"></script>

    <!--Custom JavaScript [ REQUIRED ]-->
    <script src="<?php echo e(my_asset('js/custom.js')); ?>"></script>

 



</head>
<body>

<?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div id="container" class="effect aside-float aside-bright mainnav-lg" style="padding-top:60px !important;">

     

        <div class="boxed">

            <!--CONTENT CONTAINER-->
            <!--===================================================-->
            <div >
                <div id="page-content">

                    <?php echo $__env->yieldContent('content'); ?>

                </div>
            </div>
        </div>


    </div>

    <?php echo $__env->yieldContent('script'); ?>
    <?php echo $__env->make('modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\nebula\resources\views/layouts/app.blade.php ENDPATH**/ ?>